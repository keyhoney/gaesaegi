// Firebase project configuration (override)
// 실제 배포 시 본인의 Firebase Web App 설정으로 교체하세요.
// 참고: 프로젝트 설정 → 일반 → SDK 설정 및 구성 → 구성
window.__FIREBASE_CONFIG__ = {
  apiKey: "AIzaSyCu2sVyMwlFpARnEGQsnBXJkPkbLbvasjg",
  authDomain: "honey-gsg.firebaseapp.com",
  projectId: "honey-gsg",
  storageBucket: "honey-gsg.firebasestorage.app",
  messagingSenderId: "853584351494",
  appId: "1:853584351494:web:bdf62930cc02cd27e28e87",
  measurementId: "G-B33ZSK7JFJ",
};


